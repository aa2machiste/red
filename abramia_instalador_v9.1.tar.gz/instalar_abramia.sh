#!/bin/bash
# INSTALADOR ABRAMIA V9.1 - Abraham Network C.A
if ! command -v mysql > /dev/null; then echo "[*] Instalando MariaDB..."; apt update && apt install -y mariadb-server && systemctl start mariadb && echo "[OK] MariaDB instalado"; fi
echo "=== INSTALADOR ABRAMIA V9.1 ==="
mkdir -p /root/.abramia
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
tar -xzf "$SCRIPT_DIR/backup_data.tar.gz" -C /root/ 2>/dev/null && echo "[OK] Archivos extraidos"
if command -v mysql > /dev/null; then mysql -e "CREATE DATABASE IF NOT EXISTS abramia_memory;"; fi
if [ -f "/root/.abramia/abramia_memory_dump.sql" ]; then mysql abramia_memory < /root/.abramia/abramia_memory_dump.sql && echo "[OK] DB restaurada"; fi
ls -la /root/.abramia/
echo "=== ABRAMIA V9.1 INSTALADA - Abraham Alcarra ==="
