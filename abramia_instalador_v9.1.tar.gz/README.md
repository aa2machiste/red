# ABRAMIA V9.1 - Instalador Completo

## Información General
- Versión: 9.1
- Propietario: Abraham Alcarra
- Empresa: Abraham Network C.A
- Descripción: Asistente IA con memoria persistente dual

## Instalación Rápida
tar -xzf abramia_instalador_v9.1.tar.gz && sudo bash instalar_abramia.sh

## Pasos de Instalación
1. Descomprimir: tar -xzf abramia_instalador_v9.1.tar.gz
2. Instalar: sudo bash instalar_abramia.sh
3. Verificar: ls -la /root/.abramia/

## Archivos Generados
- memoria.json: Perfil actual
- memoria_v9.json: Historial completo
- abramia_memory_dump.sql: Dump de MariaDB
- comandos.log: Log de comandos

## Base de Datos
Se crea automáticamente: abramia_memory
Tablas: memoria, aprendizajes, comandos_log

## Verificar Instalación
mysql -e "USE abramia_memory; SELECT * FROM memoria;"

## Propietario: Abraham Alcarra
## Empresa: Abraham Network C.A
## Versión: 9.1
